jQuery('document').ready(function(){
	
	var $chattername = $('#chattername');
	var $message = $('#message');
	var $btnSend = $('#send');
	var $chatbox = $('#chatbox');
	
	var socket = io();
	
	//Send message to server
	$btnSend.click(function(){
		if(sendMsg($chattername,$message)){
			socket.emit("send-msg",$chattername.val() + ": " + $message.val());
			$message.val("");
			$message.focus();
		}
	});
	
	$message.keypress(function(e){
		if(e.which == 13){
			if(sendMsg($chattername,$message)){
			socket.emit("send-msg",$chattername.val() + ": " + $message.val());
			$message.val("");
			$message.focus();
			}
		}
	});
	
	// waiting for a message
	socket.on("send-msg", function(msg){
		$chatbox.append("<p>"+msg+"</p>");
	});
	
	
	// if user is connect then download message chronik
	socket.on("msglist", function(msg){
		$chatbox.empty();
		for (var i = 0; i < msg.length; ++i){
		$chatbox.append("<p>"+msg[i]+"</p>");
		}
	});
	
});

// check message 
function sendMsg($chattername,$message){
	if($chattername.val() != "" && $message.val() != ""){
		return true;
	}else{
		return false;
	}
}