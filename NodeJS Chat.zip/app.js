var path = require("path");
var express = require('express');
var app = express();
var server = app.listen(3000);
var io = require("socket.io").listen(server);

var msglist = new Array();

app.use(express.static(path.join(__dirname, 'public')));

app.get("/", function(req,res){
	res.sendFile(__dirname + "/index.html");
	
});

io.on("connection", function(socket){
	console.log("an user is connected");
	io.emit("msglist",msglist);
	
	socket.on("send-msg", function(msg){
		io.emit("send-msg", msg);
		msglist.push(msg);
	});	
});

